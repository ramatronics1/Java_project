package greeting;

public class Greet {
	public void msg(){
		System.out.println("HELLO!! GOOD MORNING");
		
	}

}
